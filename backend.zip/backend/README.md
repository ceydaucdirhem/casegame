# Backend Kurulumu — Aşama 17

## Adım 1 — Paketleri kur

Terminalde `backend` klasörüne gir:

```bash
cd backend
npm install
```

Bu, `package.json`'daki dört paketi indirir: `express`, `cors`,
`dotenv`, `@anthropic-ai/sdk`.

## Adım 2 — API anahtarını gir

[console.anthropic.com](https://console.anthropic.com) adresinden bir
API anahtarı al (yoksa hesap oluşturup kredi yükle). Sonra `.env`
dosyasını aç ve şu satırı düzenle:

```
ANTHROPIC_API_KEY=sk-ant-xxxxxxxx...
```

Gerçek anahtarını buraya yapıştır. Bu dosya `.gitignore` sayesinde
GitHub'a asla gitmeyecek.

## Adım 3 — Sunucuyu çalıştır

```bash
npm start
```

Terminalde şunu görmelisin:

```
Sunucu http://localhost:3000 adresinde çalışıyor.
```

Eğer API anahtarını girmediysen bir UYARI mesajı da göreceksin —
sunucu yine de açılır, ama sohbet isteği attığında hata döner.

## Adım 4 — Tarayıcıdan test et

Tarayıcıda `http://localhost:3000` adresine git. Şunu görmelisin:

```json
{"durum":"Dosya: Son İfade backend çalışıyor."}
```

## Adım 5 — Sohbet endpoint'ini test et

Terminalde (sunucu çalışırken, başka bir terminal penceresinde):

```bash
curl -X POST http://localhost:3000/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "caseId": "dava_001",
    "suspectId": "supheli_001",
    "message": "Cinayet gecesi neredeydiniz?",
    "history": []
  }'
```

Beklenen sonuç, Murat Kaya karakterinin kısa ve savunmacı bir cevabı:

```json
{"reply":"Evimdeydim, eşimle televizyon izliyorduk. Başka ne diyeyim?"}
```

## Sık karşılaşılan hatalar

| Hata | Sebep / Çözüm |
|---|---|
| `Error: Cannot find module 'express'` | `npm install` çalıştırmadın. `backend` klasöründe olduğundan emin ol. |
| `401 authentication_error` (curl cevabında) | API anahtarı yanlış veya `.env`'e yazılmamış. Sunucuyu `.env`'i değiştirdikten sonra yeniden başlatmayı unutma (`Ctrl+C` sonra `npm start`). |
| `insufficient_quota` veya `credit balance too low` | Anthropic Console hesabında kredi yok. Console'dan kredi yükle. |
| `curl: command not found` (Windows) | PowerShell'de `curl` yerine `Invoke-RestMethod` kullan veya Postman/Thunder Client gibi bir araç dene. |
| Sunucu açılıyor ama `/api/chat` 404 dönüyor | `server.js` içindeki `app.use('/api', chatRoutes);` satırını kontrol et. |

## Sıradaki aşama

Flutter tarafında `api_service.dart` yazıp bu backend'e gerçek istek
atacağız, ardından yapay zekâ sohbet ekranını (`suspect_chat_screen.dart`)
oluşturup şüpheli detay ekranındaki "ŞÜPHELİYİ SORGULA" butonunu
gerçek bir sohbete bağlayacağız.
