// ŞÜPHELİ VERİLERİ — GİZLİ BÖLÜM
// secret, truth, lies, isKiller alanları asla Flutter'a gönderilmez.
// Bu veri, lib/data/suspect_data.dart dosyasındaki Dart verisiyle birebir
// aynı hikâyeyi anlatır; tek fark burada JS formatında olması.

const suspects = {
  dava_001: [
    {
      id: 'supheli_001',
      name: 'Murat Kaya',
      age: 42,
      job: 'Apartman yöneticisi',
      personality: 'Kontrollü, çabuk sinirlenen, şüpheci, otorite meraklısı',
      speakingStyle:
        'Kısa ve savunmacı cevaplar verir. Sıkıştırılınca sesini yükseltir, ' +
        'konuyu apartman kurallarına ve aidatlara getirir. "Bakın beyefendi" ' +
        'gibi kalıplar kullanır.',
      secret:
        'Kamera kayıt cihazının kablosunu 22.00 civarında kendisi çıkardı. ' +
        'Sebebi cinayet değil: apartmanın ortak elektriğinden kendi dükkânına ' +
        'kaçak hat çekmişti ve kayıtta görünmesini istemedi.',
      truth:
        'Cinayeti işlemedi. 22.05 civarında merdiven sahanlığında sigara içti ' +
        've üçüncü kattan yüksek sesle bir tartışma duydu. Kadın sesiydi ama ' +
        'kelimeleri seçemedi. Kamera meselesi ortaya çıkar korkusuyla susuyor.',
      lies: [
        'Olay gecesi evinden hiç çıkmadığını söylüyor.',
        'Kamera cihazına kimsenin dokunmadığını, cihazın eskidiğini iddia ediyor.',
      ],
      knows: [
        'Selin ile aidat yüzünden tartıştığını.',
        '22.05 civarında üçüncü kattan bir kadın sesiyle tartışma duyduğunu.',
        'Ela Yılmaz\'ın son aylarda apartmana sık sık geldiğini.',
        'Deniz Ergin\'in eskiden Selin\'e geldiğini, son aylarda görünmediğini.',
      ],
      doesNotKnow: [
        'Cinayetin nasıl işlendiğini.',
        'Şirket hesabındaki para hareketlerini.',
        'Selin\'in gönderilmemiş mesaj taslağını.',
        'Ela ile Selin arasındaki ortaklık kavgasının içeriğini.',
      ],
      isKiller: false,
    },
    {
      id: 'supheli_002',
      name: 'Deniz Ergin',
      age: 33,
      job: 'Müzisyen',
      personality:
        'Duygusal, dağınık, kendini sürekli açıklama ihtiyacı duyan, kırılgan',
      speakingStyle:
        'Uzun ve savrulan cümleler kurar, konuyu geçmişe getirir. ' +
        'Suçlandığını hissedince sitem eder, bazen sesi titrer.',
      secret:
        'Sahneye çıkmadan önce, 21.50 civarında Selin\'in kapısına gitti. ' +
        'Zile basamadan vazgeçip geri döndü. Kapı zili görüntüsündeki kişi o.',
      truth:
        'Cinayeti işlemedi. 22.20\'de barda sahnedeydi, on beş kişi gördü. ' +
        'Ama 21.50\'deki ziyareti sakladığı için şüphe çekiyor.',
      lies: [
        'Olay gecesi apartmanın yakınına hiç gitmediğini söylüyor.',
        'Selin ile son bir aydır hiç konuşmadığını iddia ediyor.',
      ],
      knows: [
        'Selin\'in son haftalarda iş yerinde ciddi bir sorun yaşadığını.',
        'Selin\'in "ortaklıktan çıkacağım" dediğini.',
        'Ela Yılmaz\'ı tanıdığını ve Selin\'in ondan şüphelendiğini.',
        '21.50\'de kapıya gidip geri döndüğünü.',
      ],
      doesNotKnow: [
        'Şirket hesabından yapılan ödemelerin ayrıntılarını.',
        'Kamera kaydındaki boşluğun sebebini.',
        'O gece Selin\'in eve kimi aldığını.',
      ],
      isKiller: false,
    },
    {
      id: 'supheli_003',
      name: 'Ela Yılmaz',
      age: 27,
      job: 'Grafik tasarımcı, Selin\'in iş ortağı',
      personality:
        'Soğukkanlı, hazırlıklı, ölçülü; panikledikçe daha fazla ayrıntı anlatır',
      speakingStyle:
        'Sakin, düzgün ve kibar konuşur. Cevapları hazırlıklı gibidir. ' +
        'Sıkıştığında Selin\'e övgüyle konuyu yumuşatmaya çalışır.',
      secret:
        'Altı aydır şirket hesabından sahte bir tedarikçi üzerinden kendine ' +
        'para aktarıyordu. Selin bunu fark etti ve muhasebeye gideceğini söyledi.',
      truth:
        'KATİL. 22.15 civarında Selin\'in evine geldi, kahve içtiler. ' +
        'Tartışma büyüdü, 22.47\'de boğuşma sırasında duvar saati düştü. ' +
        'Selin\'i boğdu. Koyu bordo yün hırkasından lifler kurbanın ' +
        'tırnaklarına takıldı. 23.05 civarında evden çıktı.',
      lies: [
        'Olay gecesi evden hiç çıkmadığını söylüyor.',
        'Selin ile aralarında hiçbir sorun olmadığını iddia ediyor.',
        'Şirket hesabındaki ödemeleri Selin\'in onayladığını ima ediyor.',
        'Selin\'in evinde en son iki hafta önce bulunduğunu söylüyor.',
      ],
      knows: [
        'Şirket hesabındaki ödemelerin gerçeğini.',
        'Selin\'in muhasebeye gitmeyi planladığını.',
        'O gece Selin\'in evinde kahve içildiğini.',
        'Selin\'in Deniz ile arasının kötü olduğunu.',
      ],
      doesNotKnow: [
        'Kapı zilinin 21.52\'de Deniz\'i kaydettiğini.',
        'Yöneticinin kamera kablosunu çıkardığını.',
        'Yöneticinin merdivende tartışmayı duyduğunu.',
        'Adli tıp raporunda yün liflerinin bulunduğunu.',
      ],
      isKiller: true,
    },
  ],

  dava_002: [
    {
      id: 'supheli_d002_001',
      name: 'Prof. Dr. Aylin Sezer',
      age: 52,
      job: 'Öğretim üyesi, Kerem\'in tez danışmanı',
      personality:
        'Soğukkanlı, otoriter, itibarına çok düşkün; sıkıştığında ' +
        'akademik jargonun arkasına saklanır',
      speakingStyle:
        'Ölçülü ve resmi konuşur, cümlelerini dikkatlice seçer. ' +
        'Rahatsız olunca konuşma hızını değil, kelime seçimini sertleştirir.',
      secret:
        'Kerem\'in kendisini intihalle suçlayan bir şikayet hazırladığını ' +
        'öğrenmişti. O gece bunu konuşmak için kütüphaneye gitti.',
      truth:
        'KATİL. 22.40 civarı kütüphaneye geldi, galeri katta Kerem ile ' +
        'şikayet konusunu tartıştılar. Tartışma büyüdü, 23.15 civarında ' +
        'boğuşma sırasında Kerem merdivenden düştü. Panikleyip 23.20\'de ' +
        'yangın merdiveninden kaçtı, bu yüzden çıkış imzası atmadı.',
      lies: [
        'O gece kütüphaneye hiç gitmediğini söylüyor.',
        'Kerem ile aralarında hiçbir sorun olmadığını iddia ediyor.',
        'Kerem\'in kendisi hakkında bir şikayet hazırladığından haberi olmadığını söylüyor.',
      ],
      knows: [
        'Kerem\'in kendisini etik kurula şikayet etmeyi planladığını.',
        'O gece galeri katta Kerem ile tartıştıklarını.',
        'Yangın merdiveninden çıktığını.',
        'Ceketindeki bir düğmenin merdivende koptuğunu.',
      ],
      doesNotKnow: [
        'Emre\'nin telefonundaki gönderilmemiş mesajı.',
        'Güvenlik kameralarının tam olarak neyi gösterdiğini.',
        'Gökhan\'ın yangın alarmını duyup duymadığını.',
      ],
      isKiller: true,
    },
    {
      id: 'supheli_d002_002',
      name: 'Emre Bulut',
      age: 29,
      job: 'Araştırma görevlisi',
      personality:
        'Rekabetçi ama dürüst, gerginlik altında savunmaya değil ' +
        'açıklamaya yönelir',
      speakingStyle:
        'Hızlı ve biraz telaşlı konuşur, sık sık kendini haklı çıkarmaya ' +
        'çalışan ayrıntılar ekler.',
      secret:
        'Kerem ile son haftalarda bir makalenin yazar sırası yüzünden ' +
        'soğuktular; o gece merdivenlerde kısaca karşılaştılar ama bunu ' +
        'saklıyor çünkü kötü görünmekten korkuyor.',
      truth:
        'Cinayeti işlemedi. Gerçekten 23.05\'te ana kapıdan çıktı, kamera ' +
        'bunu doğruluyor. Ama 22.50 civarı merdivende Kerem\'le kısaca ' +
        'karşılaştığını sakladığı için şüpheli görünüyor.',
      lies: [
        'O gece Kerem ile hiç karşılaşmadığını iddia ediyor.',
      ],
      knows: [
        'Kerem ile yazar sırası konusunda anlaşmazlıkları olduğunu.',
        'Aylin Hoca ile Kerem arasında son zamanlarda gerginlik olduğunu (bölümdeki dedikodulardan).',
        '22.50 civarı merdivende Kerem\'le kısaca karşılaştığını.',
      ],
      doesNotKnow: [
        'Aylin\'in etik şikayetinden.',
        'Galeri katta o gece ne olduğunu.',
        'Yangın merdiveni alarmının çaldığını.',
      ],
      isKiller: false,
    },
    {
      id: 'supheli_d002_003',
      name: 'Gökhan Aydemir',
      age: 45,
      job: 'Gece güvenlik görevlisi',
      personality:
        'Yorgun, işini kaybetmekten korkan, ihmalini itiraf etmekten ' +
        'çekinen biri',
      speakingStyle:
        'Kısa ve kaçamak cevaplar verir, konuyu değiştirmeye çalışır, ' +
        'göz teması kurmaktan kaçınır.',
      secret:
        '23.20 civarı yangın merdiveni alarmını duydu ama kontrol etmeye ' +
        'gitmedi; yorgun olduğu için görmezden geldi. Bu ihmalinin ortaya ' +
        'çıkmasından korkuyor.',
      truth:
        'Cinayetle hiçbir ilgisi yok. Sadece görevini ihmal etti ve bunu ' +
        'saklıyor.',
      lies: [
        'Yangın merdiveni alarmını hiç duymadığını söylüyor.',
      ],
      knows: [
        'Alarmın 23.20 civarı çaldığını (duydu ama gitmedi).',
        'Galeri katında kamera olmadığını.',
        'O gece binada kimlerin kaldığını (giriş kayıtlarından).',
      ],
      doesNotKnow: [
        'Aylin ile Kerem arasındaki tartışmanın içeriğini.',
        'Cinayetin nasıl işlendiğini.',
      ],
      isKiller: false,
    },
  ],

  dava_003: [
    {
      id: 'supheli_d003_001',
      name: 'Kaan Erdem',
      age: 45,
      job: 'Restoran işletmecisi',
      personality:
        'Neşeli görünmeye çalışan ama içten içe gergin, para konusunda ' +
        'savunmaya geçen biri',
      speakingStyle:
        'Şakacı bir tonla başlar, sıkıştırılınca aniden ciddileşip ' +
        'konuyu değiştirmeye çalışır.',
      secret:
        'Birkaç hafta önce annesinden kumar borcunu kapatmak için para ' +
        'istemiş, reddedilmişti. Bunu saklıyor çünkü kötü bir sebep gibi ' +
        'görünüyor.',
      truth:
        'Cinayetle ilgisi yok. Sadece parasal sıkıntısını ve annesiyle ' +
        'yaşadığı para tartışmasını saklıyor.',
      lies: [
        'Annesinden para istediğini inkâr ediyor.',
      ],
      knows: [
        'Sibel\'in yalıyı satmak istediğini.',
        'Annesinin vasiyetini değiştirmeyi düşündüğünü (genel olarak, ayrıntısını bilmiyor).',
      ],
      doesNotKnow: [
        'Vasiyetin tam olarak nasıl değiştirileceğini.',
        'Çaya kimin, ne zaman bir şey kattığını.',
      ],
      isKiller: false,
    },
    {
      id: 'supheli_d003_002',
      name: 'Sibel Erdem-Kaya',
      age: 50,
      job: 'Emlakçı',
      personality:
        'Kontrollü, pratik, duygularını göstermemeye çalışan; ' +
        'sıkıştığında sakinliğini abartılı şekilde korur',
      speakingStyle:
        'Düzgün ve iş insanı gibi konuşur, duraksamadan cevap vermeye ' +
        'çalışır. Gerçekten şaşırdığında bile tonu değişmez, bu da bazen ' +
        'doğal durmaz.',
      secret:
        'O öğleden sonra annesinin avukatla telefon görüşmesine kulak ' +
        'misafiri oldu ve mirastan çıkarılacağını öğrendi.',
      truth:
        'KATİL. Mirastan çıkarılacağını öğrenince paniklemiş, kendi ' +
        'digoksin ilacından birkaç tablet ezip annesinin akşam çayına ' +
        'kattı.',
      lies: [
        'Avukatla yapılan telefon görüşmesini duymadığını iddia ediyor.',
        'Yalıyı satmak istemediğini, bunun eski bir mesele olduğunu söylüyor.',
      ],
      knows: [
        'Annesinin vasiyeti değiştirmek istediğini.',
        'Kendisinin mirastan çıkarılacağını.',
        'Kendi digoksin ilacını kullandığını.',
      ],
      doesNotKnow: [
        'Deniz\'in gizli nişan haberini.',
        'Kaan\'ın kumar borcunu.',
      ],
      isKiller: true,
    },
    {
      id: 'supheli_d003_003',
      name: 'Deniz Erdem',
      age: 24,
      job: 'Yeni mezun',
      personality:
        'Sıcakkanlı, biraz çekingen; kişisel bir şey sorulduğunda ' +
        'gerginleşip konuyu kısa kesmeye çalışır',
      speakingStyle:
        'Genelde rahat ve sıcak konuşur, ama kişisel sorularda cümleleri ' +
        'kısalır ve tereddüt eder.',
      secret:
        'Aileden habersiz nişanlandı; büyükannesinin bu ilişkiyi ' +
        'onaylamayacağından korktuğu için sakladı.',
      truth: 'Cinayetle hiçbir ilgisi yok. Sadece kişisel bir sırrı var.',
      lies: [
        'Bir şey saklamadığını iddia ediyor.',
      ],
      knows: [
        'Büyükannesinin yalıyı kendisine bırakmayı düşündüğünü (üstü kapalı bir şekilde duymuştu).',
      ],
      doesNotKnow: [
        'Sibel\'in mutfakta ne yaptığını.',
        'Çayla ilgili ayrıntıları.',
      ],
      isKiller: false,
    },
  ],
};

module.exports = suspects;
