const express = require('express');
const router = express.Router();
const { sohbetGonder } = require('../controllers/chat_controller');

// POST /api/chat
// Govde: { caseId, suspectId, message, history }
router.post('/chat', sohbetGonder);

module.exports = router;
