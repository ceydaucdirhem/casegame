// Bu dosya, Flutter'dan gelen sohbet istegini karsilar:
// 1. Istekten caseId, suspectId, message, history bilgilerini alir.
// 2. Ilgili davayi ve supheliyi data/ klasorunden bulur.
// 3. suspect_prompt.js ile system prompt'u hazirlar.
// 4. ai_service.js araciligiyla Claude'dan cevap alir.
// 5. Cevabi JSON olarak Flutter'a doner.

const cases = require('../data/cases');
const suspects = require('../data/suspects');
const { buildSuspectSystemPrompt } = require('../prompts/suspect_prompt');
const { getSuspectReply } = require('../services/ai_service');

async function sohbetGonder(req, res) {
  try {
    const { caseId, suspectId, message, history } = req.body;

    // --- Girdi kontrolu ---
    if (!caseId || !suspectId || !message) {
      return res.status(400).json({
        error: 'caseId, suspectId ve message alanları zorunludur.',
      });
    }

    const caseData = cases[caseId];
    if (!caseData) {
      return res.status(404).json({ error: `Dava bulunamadı: ${caseId}` });
    }

    const suspectList = suspects[caseId] || [];
    const suspect = suspectList.find((s) => s.id === suspectId);
    if (!suspect) {
      return res.status(404).json({ error: `Şüpheli bulunamadı: ${suspectId}` });
    }

    // --- Sistem mesajini hazirla ---
    const systemPrompt = buildSuspectSystemPrompt(caseData, suspect);

    // --- Onceki konusmayi hazirla ---
    // Flutter'dan gelen history: [{role: "user"|"assistant", content: "..."}]
    // Konusma cok uzarsa hem maliyet artar hem de model eski detaylari
    // karistirmaya baslayabilir. Son 20 mesaji (10 soru-cevap turu)
    // tutmak, tutarliligi bozmadan makul bir sinir.
    const MAKSIMUM_GECMIS_UZUNLUGU = 20;
    const tumGecmis = Array.isArray(history) ? history : [];
    const temizHistory = tumGecmis.slice(-MAKSIMUM_GECMIS_UZUNLUGU);

    // --- Yapay zekadan cevap al ---
    const cevap = await getSuspectReply(systemPrompt, temizHistory, message);

    return res.json({ reply: cevap });
  } catch (hata) {
    console.error('Sohbet hatasi:', hata);
    return res.status(500).json({
      error: 'Sunucu tarafında bir hata oluştu. Lütfen tekrar deneyin.',
    });
  }
}

module.exports = { sohbetGonder };
