require('dotenv').config();

const express = require('express');
const cors = require('cors');
const chatRoutes = require('./routes/chat_routes');

const app = express();
const PORT = process.env.PORT || 3000;

// Flutter'dan gelen istekler icin CORS acik
app.use(cors());
// Gelen JSON govdesini otomatik parse et
app.use(express.json());

// Saglik kontrolu: tarayicidan http://localhost:3000 acinca calisiyor mu gorursun
app.get('/', (req, res) => {
  res.json({ durum: 'Dosya: Son İfade backend çalışıyor.' });
});

// Sohbet route'lari /api altinda
app.use('/api', chatRoutes);

app.listen(PORT, () => {
  console.log(`Sunucu http://localhost:${PORT} adresinde çalışıyor.`);
  if (!process.env.ANTHROPIC_API_KEY || process.env.ANTHROPIC_API_KEY.includes('buraya_kendi')) {
    console.warn(
      'UYARI: .env dosyasında geçerli bir ANTHROPIC_API_KEY tanımlı değil. ' +
      'Sohbet istekleri hata verecektir.'
    );
  }
});
