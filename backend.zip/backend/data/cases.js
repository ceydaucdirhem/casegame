// DAVA GERÇEKLERİ
// Bu dosya sadece backend'de durur, Flutter'a hiç gönderilmez.
// Yapay zekâya "hikâyede olmayan yeni olay uydurma" demek için
// sabit gerçekleri burada tutuyoruz.

const cases = {
  dava_001: {
    id: 'dava_001',
    title: 'Kadıköy Apartman Cinayeti',
    location: 'Moda, Kadıköy, İstanbul',
    victimName: 'Selin Aydın',
    victimAge: 29,
    victimJob: 'Grafik tasarımcı, ofis ortağı',
    timeOfDeath: '22.30 - 23.30 arası',
    // Olayın gerçek akışı, sadece yapay zekâya arka plan olarak verilir.
    // Oyuncuya asla doğrudan okunmaz.
    coreFacts: [
      'Ölüm saati 22.30 ile 23.30 arasıdır.',
      'Ölüm nedeni boyundan uygulanan baskıdır (boğma).',
      'Kapıda zorlama izi yoktur; kurban katili kendisi içeri almıştır.',
      'Mutfakta iki adet içilmiş Türk kahvesi fincanı bulunmuştur.',
      'Salondaki duvar saati boğuşma sırasında düşmüş ve 22.47\'de durmuştur.',
      'Kurbanın tırnaklarının altında koyu bordo renkli yün lifleri bulunmuştur.',
      'Apartman giriş kamerası 22.00-23.15 arası kayıt yapmamıştır; sebebi cinayetle ilgisizdir (yönetici Murat Kaya\'nın kaçak elektrik hattı).',
      'Eski sevgili Deniz Ergin 21.52\'de kapıya gelmiş, zile basmadan geri dönmüştür.',
      'Gerçek katil, iş ortağı Ela Yılmaz\'dır (supheli_003). 22.15 civarında eve gelmiş, tartışma büyümüş, 22.47 civarında Selin\'i boğmuş, 23.05 civarında evden ayrılmıştır.',
      'Cinayetin sebebi: Ela, şirket hesabından altı aydır sahte bir tedarikçi üzerinden para aktarıyordu; Selin bunu fark etmiş ve muhasebeye gideceğini söylemişti.',
    ],
    correctSuspectId: 'supheli_003',
  },
  dava_002: {
    id: 'dava_002',
    title: 'Üniversite Kütüphanesinde Son Gece',
    location: 'Beşiktaş, İstanbul',
    victimName: 'Kerem Doğan',
    victimAge: 34,
    victimJob: 'Araştırma görevlisi',
    timeOfDeath: '23.15 - 23.45 arası',
    coreFacts: [
      'Ölüm saati 23.15 ile 23.45 arasıdır.',
      'Ölüm nedeni, galeri kattan merdivene düşme sonucu kafa travmasıdır.',
      'Boyun ve ön kollarda düşmeyle açıklanamayan, boğuşmayı gösteren morluklar vardır.',
      'O gece kütüphanede kapanıştan sonra üç kişi kalmıştı: Kerem Doğan, Prof. Dr. Aylin Sezer, Emre Bulut. Ayrıca güvenlik görevlisi Gökhan Aydemir devriyedeydi.',
      'Güvenlik defterine sadece Emre Bulut (23.05) ve Gökhan Aydemir (23.30) çıkış imzası atmıştır.',
      'Kerem, tez danışmanı Aylin Sezer\'i intihalle suçlayan, gönderilmemiş bir etik kurul şikayeti hazırlamıştı.',
      'Gerçek katil Prof. Dr. Aylin Sezer\'dir (supheli_d002_001). 22.40 civarı kütüphaneye gelmiş, galeri katta Kerem ile şikayet konusunu tartışmış, 23.15 civarı boğuşma sırasında Kerem merdivenden düşmüştür.',
      'Aylin Sezer, 23.20 civarı panikleyerek yangın merdiveninden kaçmıştır; bu yüzden ana girişten çıkış imzası atmamıştır.',
      'Emre Bulut ve Gökhan Aydemir\'in cinayetle ilgisi yoktur. Emre sadece Kerem ile yazar sırası konusunda küskündü; Gökhan sadece alarmı duyup görmezden gelerek görevini ihmal etmiştir.',
    ],
    correctSuspectId: 'supheli_d002_001',
  },
  dava_003: {
    id: 'dava_003',
    title: 'Eski Aile Evinde Miras',
    location: 'Beykoz, İstanbul',
    victimName: 'Nazmiye Erdem',
    victimAge: 71,
    victimJob: 'Emekli',
    timeOfDeath: 'Akşam çayından sonra, yaklaşık 21.00-22.00 arası',
    coreFacts: [
      'Ölüm nedeni, digoksin (kalp ilacı) zehirlenmesi sonucu kalp durmasıdır; ilk bakışta doğal kalp krizi sanılmıştır.',
      'Nazmiye o sabah avukatını arayıp vasiyetini değiştirmek istediğini söylemiştir: kızı Sibel\'i mirastan çıkarıp yalıyı torunu Deniz\'e bırakmak istemektedir.',
      'O gece evde yedi kişi vardı, ancak çayların hazırlandığı saatlerde mutfağa sadece üç kişi girip çıkmıştır: Kaan, Sibel ve Deniz.',
      'Gerçek katil Sibel Erdem-Kaya\'dır (supheli_d003_002). O öğleden sonra annesinin avukatla görüşmesine kulak misafiri olmuş, mirastan çıkarılacağını öğrenmiştir.',
      'Sibel, kendi digoksin ilacından birkaç tablet ezip annesinin akşam çayına katmıştır.',
      'Kaan\'ın cinayetle ilgisi yoktur; sadece annesinden kumar borcu için para istediğini saklamaktadır.',
      'Deniz\'in cinayetle ilgisi yoktur; sadece ailesinden gizlediği bir nişan haberini saklamaktadır.',
    ],
    correctSuspectId: 'supheli_d003_002',
  },
};

module.exports = cases;
