// Bu dosya, Anthropic Claude API'sine gercek istegi atan yerdir.
// API anahtari SADECE burada, .env uzerinden okunur.

const Anthropic = require('@anthropic-ai/sdk');

const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

/**
 * Bir supheliden yapay zeka cevabi alir.
 *
 * @param {string} systemPrompt  suspect_prompt.js'ten gelen karakter kurallari
 * @param {Array<{role: 'user'|'assistant', content: string}>} history  onceki mesajlar
 * @param {string} userMessage  oyuncunun yeni mesaji
 * @returns {Promise<string>} supheliden gelen Turkce cevap
 */
async function getSuspectReply(systemPrompt, history, userMessage) {
  const response = await client.messages.create({
    model: 'claude-sonnet-4-6',
    max_tokens: 300,
    // Dusuk temperature, modelin ayni soruya her seferinde benzer ve
    // tutarli cevaplar vermesini saglar. Yaratici yazida yuksek deger
    // (0.8-1.0) tercih edilir ama bir supheli sorgusunda tutarlilik
    // yaraticiliktan daha onemli, o yuzden 0.4 kullaniyoruz.
    temperature: 0.4,
    system: systemPrompt,
    messages: [
      ...history,
      { role: 'user', content: userMessage },
    ],
  });

  // response.content bir blok listesidir; metin bloklarini birlestiriyoruz.
  const metin = response.content
    .filter((blok) => blok.type === 'text')
    .map((blok) => blok.text)
    .join('\n')
    .trim();

  return metin;
}

module.exports = { getSuspectReply };
